import { Component } from '@angular/core';
import { LandingPageComponent } from "../landing-page/landing-page.component";
import { BookNowComponent } from "../book-now/book-now.component";
import { VenueInfoComponent } from "../address/address.component";
import { GamerSlidesComponent } from "../gamer-slides/gamer-slides.component";
import { ContactComponent } from "../contact/contact.component";
import { FooterComponent } from "../footer/footer.component";

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [
    LandingPageComponent, 
    BookNowComponent, 
    VenueInfoComponent, 
    GamerSlidesComponent, 
    ContactComponent, 
    FooterComponent
  ],
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.scss'
})
export class LayoutComponent {}
