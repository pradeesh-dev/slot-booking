import { Component } from '@angular/core';
import { CarouselModule } from 'primeng/carousel';

@Component({
  selector: 'app-gamer-slides',
  imports: [
    CarouselModule
  ],
  templateUrl: './gamer-slides.component.html',
  styleUrl: './gamer-slides.component.scss',
})
export class GamerSlidesComponent {

  games: any;
  responsiveOptions: any;

  ngOnInit() {

    this.games = [
      {
        image: '../../assets/images/cricket.jpg',
        name: 'Cricket',
        description:
          'What is cricket? – Austria Cricket AssociationCricket is a bat-and-ball sport played between two teams of 11 players, with the objective of scoring runs by striking the ball and running between the wickets, while simultaneously trying to get the opposition out (taking wickets). ',
        price: 100,
      },
      {
        image: '../../assets/images/football_bg.jpg',
        name: 'Football',
        description:
          'Football is a gike association football (also known as soccer), rugby, American football, and Australian rules football. ',
        price: 300,
      },
    ];

     this.responsiveOptions = [
      {
        breakpoint: '1400px',
        numVisible: 2,
        numScroll: 1,
      },
      {
        breakpoint: '1199px',
        numVisible: 3,
        numScroll: 1,
      },
      {
        breakpoint: '767px',
        numVisible: 2,
        numScroll: 1,
      },
      {
        breakpoint: '575px',
        numVisible: 1,
        numScroll: 1,
      },
    ];
  }
}
